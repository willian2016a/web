jQuery(document).ready(function () {
    $("#deletar").click(function(){
    }
      var id =$(this).parent("td:eq(0)");
      $.post("Home/deletar",{id: id.val},function(){
      	  location.reload();
      });
    });
});