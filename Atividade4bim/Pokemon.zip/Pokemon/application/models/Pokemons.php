<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pokemons extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function consultar(){
        return $this->db->get("pokemons")->result_array();

    }
   public function inserir($nomePokemon,$tipoPokemon,$dataCaptura){
	   $vetor = array(
	      "nomePokemon" => $nomePokemon,
	      "dataCaptura" => $dataCaptura,
	      "tipoPopkemon"=> $tipoPokemon
	   );
	   
	   $this->db->insert("pokemon",$vetor);
	   	   }
	   	   
	public function deletar(){
	   $this->db->where("idPokemon",$idPokemon);
	   $this->db->delete("pokemon");
	}	   
	  
}
