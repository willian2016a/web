<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function index() {
        if ($this->session->has_userdata("logado")) {
		   $this->load->model("Pokemons");
           $pokemons = $this->Pokemons->consultar();
           $vetor = array(
               "pokemon" => $pokemons
            );
           $this->parser->parse("home",$vetor);
        } else {
            redirect(base_url("Login"));
        }
    }
  public function inserir(){
	  $this->load->modal("Pokemon");
	  $nomePokemon = $this->input->post()["nomePokemon"];
	  $tipoPokemon = $this->input->post()["tipoPokemon"];
	  $dataCaptura = $this->input->post()["dataCaptura"];
  }
  
  public function deletar(){
		   $id = $this->input->post()["idPokemon"];
		   $this->load->model("Pokemon");
		   $this->Pokemon->deletar("idPokemon");
	}
}
