<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>home</title>
    <link href="<?php echo base_url("assets/css/bootstrap.min.css"); ?>" rel="stylesheet">
    <link href="<?php echo base_url("assets/css/home.css"); ?>" rel="stylesheet">
  </head>
<body>
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Pokémon</a>
        </div>
        
    <div class="container">
      <div class="jumbotron">
       <table class="table table-condensed">
		   <thead>
			  <tr>
			   <th>ID</th>
			   <th>Nome</th>
			   <th>Data de captura</th>
			   <th>Tipo do pokémon</th>
			   <th>Editar</th>
			   <th>Excluir</th>
			 </tr>
		   <thead>
		   <tbody>
			   {pokemon}
			     <tr>
					<td>{idPokemon}</td>
					<td>{nomePokemon}</td>
					<td>{dataCaptura}</td>
					<td>{tipoPokemon}</td>
					<td><button type="button" class="btn btn-success"><span class="glyphicon glyphicon-wrench"></span></span></button></td>
					<td><button type="button"class="btn btn-danger primeira"><span class="glyphicon glyphicon-trash"></button></td>
					
			     </tr>
			   {/pokemon}
		   <tbody> 
       </table>
         <button type="button" data-toggle="modal" data-target="#modal2" class="btn btn-warning">Novo</button>
      </div>
    </div> 
  </body>
    <script src="<?php echo base_url("assets/js/segundo.js") ?>"></script>
    <script src="<?php echo base_url("assets/js/jquery.min.js") ?>"></script>
    <script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>"></script>
</html>





<div class="modal fade" tabindex="-1" role="dialog" id="modal2">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Novo pokémon</h4>
      </div>
      <div class="modal-body">
        <form  method="POST" action="Home/inserir" id="inserir" class="form-horizontal">
			
  <div class="form-group">
    <label for="pokemon" class="col-sm-2 control-label">Nome pokémon</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="nomePokemon" placeholder="nome">
    </div>
  </div>
  
  <div class="form-group">
    <label for="tipoPokemon" class="col-sm-2 control-label">Tipo pokémon</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="tipoPokemon" placeholder="tipo">
    </div>
  </div>
  
  <div class="form-group">
    <label for="tipoPokemon" class="col-sm-2 control-label">Data da captura</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="dataCaptura" placeholder="tipo">
    </div>
  </div>
  
  <div class="form-group">
	   <div class="radio">
        <label>
         <input type="radio" name="tipoPokemon" id="optionsRadios1" value="option1" checked>Verde 
         </label>
      </div>
      
      <div class="radio">
       <label>
       <input type="radio" name="tipoPokemon" id="optionsRadios1" value="option2" checked>
         Laranja
        </label>
       </div>
       
       <div class="radio">
      <label>
        <input type="radio" name="tipoPokemon" id="optionsRadios1" value="option3" checked>
       Vermelho
      </label>
      </div>
      
  </div>
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary">Salvar</button>
      </div>
    </div>
  </div>
</div>
