<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	 
	public function index(){
		$this->load->view('pagina_inicial');
		}
		
	public function formulario_cadastro(){
		$this->load->helper('form');
		$this->load->view('formulario_cadastro');		
	}
    
	
	public function adicionar(){
		$data['nomeArquivo'] = $this->input->post('txt_nome');
		$data['titulo'] = $this->input->post('txt_titulo');
		$data['autores'] = $this->input->post('txt_autores');
		$data['citacoes'] = $this->input->post('txt_citacoes');
		$data['referencias'] = $this->input->post('txt_referencia');
		$data['palavrasChave'] = $this->input->post('txt_palavra');
		
		if($this->db->insert('citacoes',$data)){
			redirect(base_url());
		}		
	else{
	echo"Não foi possível gravar a postagem no BD!";
	}
}

public function lista(){
		$variavel['citacoes'] = $this->db->get('citacoes')->result();
        $this->load->view('lista' ,$variavel);
    }
  //public function error404() {
  //	   $this->load->view('error404');
//}	

}
