-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 23-Set-2016 às 10:50
-- Versão do servidor: 5.5.47-0ubuntu0.14.04.1
-- versão do PHP: 5.5.9-1ubuntu4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `RefBib`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `citacoes`
--

CREATE TABLE IF NOT EXISTS `citacoes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nomeArquivo` varchar(255) CHARACTER SET utf8 NOT NULL,
  `titulo` text CHARACTER SET utf8 NOT NULL,
  `autores` text CHARACTER SET utf8 NOT NULL,
  `citacoes` text CHARACTER SET utf8 NOT NULL,
  `referencias` text CHARACTER SET utf8 NOT NULL,
  `dataCadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `palavrasChave` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Extraindo dados da tabela `citacoes`
--

INSERT INTO `citacoes` (`id`, `nomeArquivo`, `titulo`, `autores`, `citacoes`, `referencias`, `dataCadastro`, `palavrasChave`) VALUES
(1, 'Teste', 'teste', 'sdfdfsdf', 'sdfsdfsdfsd', 'sdfsdfsdfsdf', '2016-09-23 11:56:59', 'sdfsdfsd'),
(2, '', '', '', '', '', '2016-09-23 12:43:26', ''),
(3, 'dfsdf', 'sdfsdf', 'sdfsd', 'dfdf', 'dfds', '2016-09-23 12:44:11', 'dsfdsf'),
(4, '', '', '', '', '', '2016-09-23 12:44:13', ''),
(5, '', '', '', '', '', '2016-09-23 12:44:13', ''),
(6, '', '', '', '', '', '2016-09-23 12:44:13', ''),
(7, '', '', '', '', '', '2016-09-23 12:44:13', ''),
(8, '', '', '', '', '', '2016-09-23 12:44:13', ''),
(9, '', '', '', '', '', '2016-09-23 12:44:15', ''),
(10, '', '', '', '', '', '2016-09-23 12:44:15', ''),
(11, '', '', '', '', '', '2016-09-23 12:44:16', ''),
(12, '', '', '', '', '', '2016-09-23 12:44:16', ''),
(13, '', '', '', '', '', '2016-09-23 12:44:16', ''),
(14, '', '', '', '', '', '2016-09-23 12:46:05', ''),
(15, '', '', '', '', '', '2016-09-23 12:46:06', ''),
(16, 'dDD', '', '', '', '', '2016-09-23 12:46:08', ''),
(17, '', '', '', '', '', '2016-09-23 12:46:08', ''),
(18, 'qwertyui', 'sadfrgthyj', 'sdfrgthj', 'asdfgh', 'asdfgh', '2016-09-23 12:49:28', 'sdfgh'),
(19, 'dfxgcfhgj', 'dfxgfhnjm', 'fshy', 'sdafzh', 'dfsegrdth', '2016-09-23 12:54:21', 'grgrdg'),
(20, 'Eduardo', 'sdfsdf', 'sdfrgthj', 'dfdf', 'sddddd', '2016-09-23 12:56:15', 'dsfdsf'),
(21, 'Eduardo', 'sadfrgthyj', 'sdfrgthj', 'ddddd', 'sddddd', '2016-09-23 12:59:50', 'dsfdsf'),
(22, 'Eduardo', 'sdfsdf', 'sdfrgthj', 'ddddd', 'sddddd', '2016-09-23 13:01:04', 'dsfdsf'),
(23, 'Eduardooooooooo', 'asdfghgsasdghgfdsa', 'sdfgsadfgfdsa', 'sdfgfdsdfgfdsa', 'sdfdsadfgfdsa', '2016-09-23 13:49:50', 'sdfgfdsdfgfds');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
