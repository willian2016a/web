<?php
	require_once 'init.php';
	// abre a conexão
	$PDO=db_connect();
	/* SQL para contar o total de registros */
	$sql_count = "SELECT COUNT(*) AS total FROM clientes ORDER BY nomeCliente ASC";
	// SQL para selecionar os registros
	$sql = "SELECT idCliente, nomeCliente, dataCadastro, email FROM clientes ORDER BY nomeCliente ASC";
	// conta o total de registros
	$stmt_count=$PDO->prepare($sql_count);
	$stmt_count->execute();
	$total=$stmt_count->fetchColumn();
	// seleciona os registros
	$stmt=$PDO->prepare($sql);
	$stmt->execute();

	require('fpdf/fpdf.php');

	$pdf = new FPDF('P','pt','A4');
 	$pdf->SetTitle('Mala Direta Clientes');
	$pdf->SetAuthor('Edgard Alexandre e Willian Alves');
	$pdf->Setcreator('php'.phpversion());
	$pdf->Setkeywords('php','pdf');
 	$pdf->SetSubject(' qualquer merda ');

	while($cliente = $stmt->fetch(PDO::FETCH_ASSOC)){
		$nome = $cliente['nomeCliente'];

 		$pdf->addPage();

		//definir a fonte
 		$pdf->SetFont('Arial','',12);
 		$pdf->text(0,12,' ');
	
		//espaçamento vertical
		$pdf->Ln(20);
 		$pdf->SetFont('Arial','',12);
 		$pdf->SetTextColor(' ');
 		$pdf->SetY(20);
 		$pdf->SetX(450);
 
 		$titulo = 'Varginha, '.date("d/m/y");
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);

		$pdf->Ln(20);
 		$pdf->SetFont('Arial','',12);
 		$pdf->SetTextColor('');
		$pdf->SetY(70);
		$pdf->SetX(50);


		$titulo = 'Prezado(a) Sr(a) '.$nome.',';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);


		$pdf->Ln(20);
 		$pdf->SetFont('Arial','',11);
 		$pdf->SetTextColor('');
		$pdf->SetY(150);
		$pdf->SetX(80);

		$titulo = 'Neste mês de aniversário, nossa loja está com promoções imperdíveis e selecionadas';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);

		$pdf->Ln(15);
 		$pdf->SetFont('Arial','',11);
 		$pdf->SetTextColor('');
		$pdf->SetX(50);


		$titulo = 'especialmente para você.';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);

		$pdf->Ln(15);
		$pdf->SetFont('Arial','',11);
 		$pdf->SetTextColor('');
		$pdf->SetX(80);

		$titulo = 'Não perca esta oportunidade de realizar bons negócios.';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);

		$pdf->Ln(15);
		$pdf->SetFont('Arial','',11);
 		$pdf->SetTextColor('');
		$pdf->SetX(80);

		$titulo = 'Faça-nos umas visita.';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);

		$pdf->Ln(20);
		$pdf->SetFont('Arial','',11);
 		$pdf->SetTextColor('');
		$pdf->SetY(300);
		$pdf->SetX(50);

		$titulo = 'Cordialmente,';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);

		$pdf->SetFont('Arial','',10);
 		$pdf->SetTextColor('');
		$pdf->SetY(400);
		$pdf->SetX(215);

		$titulo = 'Edgard Alexandre e Willian Alves';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);

		$pdf->Ln(15);		
		$pdf->SetFont('Arial','',12);
 		$pdf->SetTextColor('');
		$pdf->SetX(235);

		$titulo = 'Gerentes Comerciais';
 		$titulo = utf8_decode($titulo);
		$pdf->Write(30,$titulo);
	}

	$pdf->Output();
?>
