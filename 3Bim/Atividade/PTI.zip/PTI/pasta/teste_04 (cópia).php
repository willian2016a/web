<?php
  // inclui classes necessárias
  spl_autoload_register(function ($class_name)
  {
    include 'html/'.$class_name.'.class.php';
  });

  // constroi matriz com os dados

  $dados[] = array(1, 'Marcelo Mussel', 'marcelo.mussel@gmail.com', 1200);
  $dados[] = array(2, 'Dilma Roussef', 'dilma@gmail.com', 1500);
  $dados[] = array(3, 'Lula do Brasil', 'lulala@gmail.com', 1000);
  $dados[] = array(4, 'Eddie the Hunter', 'eddie@gmail.com', 1800);
  $dados[] = array(5, 'Iron Maiden', 'heavy@gmail.com', 2000);

  // *********************************************************
  // corrigir caracteres
  $html = new TElement('html');
  $html->lang = 'pt-br';
  //instancia seção head
  $head = new TElement('head');
  $html->add($head); //adiciona ao html
  $meta = new TElement('meta');
  $meta->charset = 'utf-8';
  $head->add($meta);

  $body = new TElement('body');
  $body->bgcolor = '#ffffdd';
  $html->add($body);

  // *********************************************************
  //instancia objeto-tabela
  $tabela = new TTable;
  //define algumas propriedades
  $tabela->width = 600;
  $tabela->border = 1;
  //instancia uma linha para o cabeçalho
  $cabecalho = $tabela->addRow();
  //define a cor de fundo
  $cabecalho->bgcolor = '#a0a0a0';
  //adiciona células
  $cabecalho->addCell('Código');
  $cabecalho->addCell('Nome');
  $cabecalho->addCell('E-Mail');
  $cabecalho->addCell('Salário');

  $i = 0;
  $total = 0;
  //percorre os dados
  foreach($dados as $pessoa)
  {
    // verifica qual cor utilizará para o fundo
    $bgcolor = ($i % 2) == 0 ? '#d0d0d0' : '#ffffff';
    // adiciona uma linha para os dados
    $linha = $tabela->addRow();
    $linha->bgcolor = $bgcolor;
    // adiciona as células
    $linha->addCell($pessoa[0]);
    $linha->addCell($pessoa[1]);
    $linha->addCell($pessoa[2]);
    $x = $linha->addCell($pessoa[3]);
    $x->align = 'right';

    $total += $pessoa[3];
    $i++;
  }
  //instancia uma linha para o totalizador
  $linha = $tabela->addRow();
  //adiciona células
  $celula = $linha->addCell('Total');
  $celula->colspan = 3;
  $celula = $linha->addCell($total);
  $celula->bgcolor = '#a0a0a0';
  $celula->align = 'right';

  // exibe a tabela
  //$tabela->show();
  $body->add($tabela);
  $html->show();
?>
