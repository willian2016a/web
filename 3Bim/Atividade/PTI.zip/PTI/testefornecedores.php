<?php
require_once 'init-cliente.php';
  /*
   * função __autoload()
   * Carrega uma classe quando ela é necessária,
   * ou seja, quando é instanciada pela primeira vez.
  */
  spl_autoload_register(function ($class_name)
  {
	include 'html/'.$class_name.'.class.php';
  });
	include 'ado/TConnection.class.php';

  // define a consulta SQL
  $sql = "SELECT idFornecedor, nomeFornecedor, email, dataFundacao FROM fornecedores";
  try
  {
    // abre a conexão com a base BD_CEFETMG
    $conn = TConnection::open('config/my_config.ini');
    // executa a instrução SQL
    $result = $conn->query($sql);
    


// corrigir caracteres
  $html = new TElement('html');
  $html->lang = 'pt-br';
  //instancia seção head
  $head = new TElement('head');
  $html->add($head); //adiciona ao html
  $meta = new TElement('meta');
  $meta->charset = 'utf-8';
  $head->add($meta);

  $body = new TElement('body');
  $body->bgcolor = '#ffffdd';
  $html->add($body);
	$div =new TElement('div');
 $div->id='variavel';
  $body->add($div);

  // *********************************************************
  //instancia objeto-tabela
  $tabela = new TTable;
  //define algumas propriedades
  $tabela->width = 600;
  $tabela->border = 1;
$div->add($tabela);
  //instancia uma linha para o cabeçalho
  $cabecalho = $tabela->addRow();
  //define a cor de fundo
  $cabecalho->bgcolor = '#a0a0a0';
  //adiciona células
  $cabecalho->addCell('ID Fornecedor');
  $cabecalho->addCell('Nome');
  $cabecalho->addCell('Email');
  $cabecalho->addCell('Data Fundacão');

$i=0;
    while($row = $result->fetch(PDO::FETCH_ASSOC)) // Exibe todos os registros
    {
     
    // verifica qual cor utilizará para o fundo
    $bgcolor = ($i % 2) == 0 ? '#d0d0d0' : '#ffffff';
    // adiciona uma linha para os dados
    $linha = $tabela->addRow();
    $linha->bgcolor = $bgcolor;
    // adiciona as células
    $linha->addCell($row['idFornecedor']);
    $linha->addCell($row['nomeFornecedor']);
    $linha->addCell($row['email']);
    $x = $linha->addCell(dateConvert($row['dataFundacao']));
    $x->align = 'right';

   
$i++;
    }
 
  $body->add($tabela);
 $html->show();
    //fecha a conexão
    $conn = null;
  } catch (Exception $e) {
    // exibe a mensagem de erro
    print "Erro! " . $e->getMessage() . "<br/>";
  }
 

  // *********************************************************
  
?>
