function aviso(){
   alert("teste");
}

$(document).ready(function(e){
    $(".conteudoAluno").hide();
    $(".conteudoRelatorio").hide();
    $(".conteudoBackup").hide();
    $(".conteudoAtividade").hide();
  $(".cssImagens a").click(function(e){
      e.preventDefault();
      var href = $(this).attr('href');
      $(".conteudo").load(href + " .conteudo");
  });

  $(".menuTopo a").click(function(e){
      e.preventDefault();
      var href = $(this).attr('href');
      if($(this).attr("id").match(".conteudoAluno")){
        $(".cssImagens").hide();
        $(".conteudoAluno").show();
      }else if($(this).attr("id").match(".conteudoAtividade")){
        $(".cssImagens").hide();
        $(".conteudoAtividade").show();
      }else if($(this).attr("id").match(".conteudoBackup")){
        $(".cssImagens").hide();
        $(".conteudoBackup").show();
      }else if($(this).attr("id").match(".conteudoRelatorio")){
        $(".cssImagens").hide();
        $(".conteudoRelatorio").show();
      }
  });
});

